package andreafrancia.largefileviewer;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;

public class LargeFileCreator {

    public static void main(String[] args) throws Exception {
        PrintWriter out =
                new PrintWriter(
                new BufferedWriter(new FileWriter("test-file.txt"), 1024 * 1024));
        int numberOfLines = (1024 * 1024 * 1024) / 10;
        System.out.println("Lines to write: " + numberOfLines);
        for (int i = 0; i < numberOfLines; i++) {
            out.println(String.format("Line no. %d", i));
            if ((i % (1024 * 1024) == 0) && (i != 0)) {
                System.out.printf("Written %d lines.%n", i);
            }
        }
        out.close();
    }
}
