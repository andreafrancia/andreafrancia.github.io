package andreafrancia.largefileviewer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractListModel;

public class LazyFileListModel extends AbstractListModel {

    private static Logger logger =
            Logger.getLogger(LazyFileListModel.class.getName());
    private RandomAccessFile lineCounterFile;
    private List<Long> linePositions =
            Collections.synchronizedList(new ArrayList<Long>());
    private RandomAccessFile readerFile;

    /**
     * Create a <tt>LazyFileListModel</tt> that read list item from the specified 
     * file.
     * Each element of the list is a line of the file.
     * @param file
     * @throws java.io.FileNotFoundException 
     */
    public LazyFileListModel(File file) throws FileNotFoundException {
        this.lineCounterFile = new RandomAccessFile(file, "r");
        this.readerFile = new RandomAccessFile(file, "r");
        Runnable lineCounterThread = new Runnable() {

            public void run() {
                try {
                    String line;
                    while ((line = lineCounterFile.readLine()) != null) {
                        linePositions.add(lineCounterFile.getFilePointer());
                        Thread.yield();
                    }
                    linePositions.remove(linePositions.size() - 1);
                } catch (IOException ex) {
                    logger.log(Level.SEVERE, "", ex);
                }

            }
        };
        Executors.newSingleThreadExecutor().submit(lineCounterThread);

        Runnable firer = new Runnable() {

            public void run() {
                int last = -1;
                int current = linePositions.size() - 1;
                if (last < current) {
                    fireIntervalAdded(LazyFileListModel.this, last + 1, current);
                    last = current;
                }
            }
        };

        Executors.newScheduledThreadPool(1).scheduleAtFixedRate(firer, 2, 500,
                TimeUnit.MILLISECONDS);
    }

    public int getSize() {
        return linePositions.size();
    }

    public Object getElementAt(int index) {
        try {
            readerFile.seek(linePositions.get(index));
            return String.format("%06d: %s", index, readerFile.readLine());
        } catch (IOException ex) {
            logger.log(Level.SEVERE, "", ex);
            return null;
        }
    }
}
