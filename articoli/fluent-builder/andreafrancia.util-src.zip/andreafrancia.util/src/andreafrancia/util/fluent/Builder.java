package andreafrancia.util.fluent;

public interface Builder<T> {
    T build();
}
