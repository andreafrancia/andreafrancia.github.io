package example;

import andreafrancia.util.ToStringHelper;
import andreafrancia.util.fluent.BuilderFactory;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Person {
    private int age;
    private List<String> lovedThings = new ArrayList<String>();
    private String firstName;
    private String lastName;    
    
    public Person() {
    }

    public int getAge() {
        return age;
    }

    public List<String> getLovedThings() {
        return this.lovedThings;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setLovedThings(List<String> newbars) {
        this.lovedThings = newbars;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    public interface Builder extends andreafrancia.util.fluent.Builder<Person> {
        public Builder withFirstName(String firstName);   
        public Builder withLastName(String lastName);
        public Builder withLovedThings(String... bars);
        public Builder withAge(int age);
        public Person build();
    }

    public static Builder builder() {
        return BuilderFactory.createBuilder(new Person(), Builder.class);
    }
    
    public String toString() {
        return ToStringHelper.toString(this);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Person other = (Person) obj;
        if (this.age != other.age) {
            return false;
        }
        if (this.lovedThings != other.lovedThings &&
                (this.lovedThings == null ||
                !this.lovedThings.equals(other.lovedThings))) {
            return false;
        }
        if (this.firstName != other.firstName &&
                (this.firstName == null ||
                !this.firstName.equals(other.firstName))) {
            return false;
        }
        if (this.lastName != other.lastName &&
                (this.lastName == null || !this.lastName.equals(other.lastName))) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 23 * hash + this.age;
        hash =  23 * hash +
                (this.lovedThings != null ? this.lovedThings.hashCode() : 0);
        hash =  23 * hash +
                (this.firstName != null ? this.firstName.hashCode() : 0);
        hash =  23 * hash +
                (this.lastName != null ? this.lastName.hashCode() : 0);
        return hash;
    }
    
    
}  