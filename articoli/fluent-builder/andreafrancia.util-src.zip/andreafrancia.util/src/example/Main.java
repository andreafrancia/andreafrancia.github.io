package example;

public class Main {

    public static void main(String[] args) {
        Person person = new Person();
        person.setFirstName("John");
        person.setLastName("Smith");
        person.getLovedThings().add("pizza");
        person.getLovedThings().add("soccer");
        person.getLovedThings().add("jogging");
        person.setAge(30);

        Person person2 = Person.builder()
                .withFirstName("John")
                .withLastName("Smith")
                .withLovedThings("pizza", "soccer", "jogging")
                .withAge(30)
                .build();
        
        System.out.println(person);
        System.out.println(person2);
        System.out.println("equals: " + person.equals(person2));
    }

}
